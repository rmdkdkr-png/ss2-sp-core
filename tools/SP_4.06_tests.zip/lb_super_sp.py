from pathlib import Path
from xemu import *
import json
p=Path(__file__).parent;old=p.parent/'lb_sp';e=Emu(str(p/'final_candidate.dll'),'C:/Claude/월화 한글/rom/orig.ngc');D={'1':6,'2':2,'3':10,'4':4,'5':0,'6':8,'8':1}
def rp(v):return (16 if v&1 else 0)|(32 if v&2 else 0)|(64 if v&4 else 0)|(128 if v&8 else 0)|(1 if v&16 else 0)|(256 if v&32 else 0)
def flip(v):return(v&~12)|((v&4)<<1)|((v&8)>>1)
es=['2141236AB','2141236AB','641236AB','236236AB','641236AB','2141236AB','2141236AB','2141236AB','463214AB','2141236AB','641236AB','641236AB','2141236AB','236236AB','641236A']
ht=['2141236B','2141236B','641236B','2141236B','641236B','2141236B','2141236B','236236B','463214B','463214B','463214B',None,'641236B','463214B','641236AB']
cases=[]
for cid in range(15):
 cases += [(cid,es[cid],1,0,False),(cid,'252A',257,0,True)]
 if ht[cid]:cases.append((cid,ht[cid],256,0,False))
cases += [(0,'236236AB',1,8,False),(0,'236236B',256,8,False),(14,'641236B',1,8,False),(14,'463214B',1,2,False)]
cases += [(11,'j41236AB',1,0,False),(11,'j41236B',256,0,False),(14,'j236A',1,0,False)]
out=[]
for cid,cmd,mod,dmod,speed in cases:
 for side in [0,1]:
  for ph in [0,1]:
   row=[cid,cmd,mod,dmod,speed,side,ph]
   for mode in ['manual','sp']:
    e.load(p/f'lb_speed{cid}.st' if speed else old/(f'flip{cid}.st' if side else f'id{cid}.st'))
    if speed and side:e.run(60,128);e.run(30,144);e.run(80)
    if cid==12 and mod==256:e.run(50,64 if e.ram()[0x386]==1 else 128);e.run(20)
    if cmd.startswith('j'):e.run(4,16);e.run(12)
    e.run(ph);left=e.ram()[0x386]==1;s=cmd.lstrip('j').rstrip('AB');btn=48 if cmd.endswith('AB') else 16 if cmd.endswith('A') else 32;acts=[]
    def tick(v,ret=0):
     e.run(1,rp(flip(v) if left else v)|ret);a=e.ram()[0x370]
     if a not in ([4,12,16,20,24,36,40,44,48] if cmd.startswith('j') else [4,12,16,20,24]) and (not acts or acts[-1]!=a):acts.append(a)
    if mode=='manual':
     for d in s:
      for _ in range(4):tick(D[d])
     for _ in range(4):tick(btn)
    else:
     for _ in range(2):tick(dmod,2048|mod)
    for _ in range(240):tick(0)
    row.append(acts)
   out.append(row)
 print(cid,cmd,flush=True)
(p/'lb_super_sp.json').write_text(json.dumps(out));print('pass',sum(r[7][:2]==r[8][:2] and bool(r[7]) for r in out),len(out));e.close()
