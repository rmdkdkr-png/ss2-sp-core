from pathlib import Path
from xemu import *
import json
p=Path(__file__).parent;e=Emu(str(p/'extended.dll'),'C:/Claude/KOF R2 한글/rom/orig.ngc');D={'1':6,'2':2,'3':10,'4':4,'5':0,'6':8,'8':1}
def rp(v):return (16 if v&1 else 0)|(32 if v&2 else 0)|(64 if v&4 else 0)|(128 if v&8 else 0)|(1 if v&16 else 0)|(256 if v&32 else 0)
def flip(v):return(v&~12)|((v&4)<<1)|((v&8)>>1)
neutral={213,180,143,171,64,75,177,223,191};spec=json.loads((p/'kof_supers.json').read_text());rows=[]
def trial(cid,cmd,mode,side,phase,reload=True):
 if reload:
  e.load(p/(f'kof_flip{cid}.st' if side else f'kof_id{cid}.st'));e.run(35,64 if e.ram()[0xd4c]&128 else 128);e.run(20+phase)
 s=cmd
 if s[0]=='j':e.run(4,16);e.run(8);s=s[1:]
 ds=[D[d] for d in s[:-1]];btn=16 if s[-1]=='A' else 32;left=bool(e.ram()[0xd4c]&128);acts=[]
 def tick(v,ret=0):
  e.run(1,rp(flip(v) if left else v)|ret);a=e.ram()[0xd3c]
  if a not in neutral and (not acts or acts[-1]!=a):acts.append(a)
 if mode=='manual':
  for d in ds:
   for _ in range(4):tick(d)
  for _ in range(4):tick(ds[-1]|btn)
 else:
  mod=[1,256,257][spec[cid].index(cmd)]
  for _ in range(2):tick(0,2048|mod)
 for _ in range(240):tick(0)
 return acts
for cid,cmds in enumerate(spec):
 for cmd in cmds:
  for side in [0,1]:
   for ph in [0,1]:
    a=trial(cid,cmd,'manual',side,ph);b=trial(cid,cmd,'sp',side,ph);ok=a[:2]==b[:2] and bool(a)
    rows.append(dict(cid=cid,cmd=cmd,side=side,phase=ph,ok=ok,manual=a,sp=b))
 print(cid,flush=True)
continuous=[]
for cid,cmds in enumerate(spec):
 cmd=cmds[0];ref=trial(cid,cmd,'manual',0,0)[:2];e.load(p/f'kof_id{cid}.st');ans=[]
 for i in range(5):
  e.run(35,64 if e.ram()[0xd4c]&128 else 128);e.run(20)
  a=trial(cid,cmd,'sp',0,0,False);ans.append(a[:2]==ref);e.run(500)
 continuous.append([cid,ans])
report=dict(rows=rows,continuous=continuous,queries=e.queries);(p/'kof_stress.json').write_text(json.dumps(report));print('pass',sum(r['ok'] for r in rows),len(rows),'continuous',continuous);e.close()
