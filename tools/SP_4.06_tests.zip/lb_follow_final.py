import sys,json
from pathlib import Path
from xemu import *
p=Path(__file__).parent;old=p.parent/'lb_sp';e=Emu(str(p/'final_candidate.dll'),'C:/Claude/월화 한글/rom/orig.ngc')
D={'1':6,'2':2,'3':10,'4':4,'5':0,'6':8,'8':1}
def rp(v):return (16 if v&1 else 0)|(32 if v&2 else 0)|(64 if v&4 else 0)|(128 if v&8 else 0)|(1 if v&16 else 0)|(256 if v&32 else 0)
def flip(v):return(v&~12)|((v&4)<<1)|((v&8)>>1)
cases=[(1,'623A',48,0,16),(5,'28B',48,0,16),(5,'28B',48,2,32),(5,'623A',64,2,18),(5,'623A',64,6,34),(6,'[4]6B',12,0,16),(6,'[4]6B',12,2,32),(6,'[4]6B',12,4,36),(6,'214A',4,0,16),(7,'214B',4,0,32),(9,'[2]8A',24,0,18),(9,'63214A',4,0,16),(9,'AB',4,0,16),(9,'AB',4,4,32),(9,'AB',4,8,40),(9,'AB',4,2,34),(10,'41236B',12,0,16),(10,'41236B',12,4,32),(11,'236B',16,0,16),(12,'AB',4,0,8),(12,'AB',4,4,4),(14,'214A',12,0,16),(13,'63214B',24,0,32)]
out=[]
for cid,cmd,delay,mod,follow,side,phase in [tuple(r)+(s,ph) for r in cases for s in [0,1] for ph in [0,1]]:
 row=[cid,cmd,delay,mod,follow,side,phase]
 for mode in ['none','manual','sp']:
  e.load(old/(f'flip{cid}.st' if side else f'id{cid}.st'));e.run(50,64 if e.ram()[0x386]==1 else 128);e.run(20);r=e.ram();left=r[0x386]==1;ptr=e.lib.retro_get_memory_data(2);s=cmd;pre=[]
  if s.startswith('['):pre=[D[s[1]]]*40;s=s[3:]
  ds=[D[d] for d in s.rstrip('AB')];btn=48 if s=='AB' else 16 if s.endswith('A') else 32
  live=ds[-1] if ds and ds[-1] in [1,2,4,8] else 0;hist=pre+(ds[:-1] if live else ds);h=r[0x1312]
  for j,d in enumerate(hist):C.c_uint8.from_address(ptr+0x1313+((h-len(hist)+j)&127)).value=flip(d) if left else d
  if live:e.run(2,rp(flip(live) if left else live))
  e.run(12,rp(btn|(live if live==1 else 0)));e.run(delay+phase);acts=[];initial=e.ram()[0x370]
  left=e.ram()[0x386]==1
  for t in range(124):
   if cid==13 and mode=='manual':v=([4,6,2,10,8][t//4] if t<20 else 32 if t<24 else 0)
   else:v=follow if mode=='manual' and t<4 else mod if mode=='sp' and t<2 else 0
   e.run(1,rp(flip(v) if left else v)|(2048 if mode=='sp' and t<2 else 0));a=e.ram()[0x370]
   if not acts or acts[-1]!=a:acts.append(a)
  row.append([initial,acts])
 out.append(row)
(p/'lb_follow_final.json').write_text(json.dumps(out));print('cases',len(out),'equal',sum(r[8]==r[9] for r in out));e.close()
