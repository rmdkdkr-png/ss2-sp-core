import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'ss2'));from xemu import *
p=Path(__file__).parent;e=Emu(str(p/'final_candidate.dll'),'C:/Claude/KOF R2 한글/rom/orig.ngc');D={'1':6,'2':2,'3':10,'4':4,'5':0,'6':8,'8':1}
left=False
def rp(v):
 if left:v=(v&~12)|((v&4)<<1)|((v&8)>>1)
 return (16 if v&1 else 0)|(32 if v&2 else 0)|(64 if v&4 else 0)|(128 if v&8 else 0)|(1 if v&16 else 0)|(256 if v&32 else 0)
spec=[(0,'236A','236A'),(0,'236A','63214A'),(0,'236B','B'),(2,'214A','623A'),(4,'[4]6B','6B'),(5,'41236A','236A'),(6,'214A','236B'),(6,'623B','236B'),(6,'41236A','236B'),(8,'463214A','214A'),(10,'214A','214A'),(13,'214A','214A')]
def command(cmd,hold=4):
 if not cmd:return []
 ds=[]
 if cmd[0]=='[':ds=[(80,D[cmd[1]])];cmd=cmd[3:]
 btn=16 if cmd[-1]=='A' else 32
 ds += [(4,D[d]) for d in cmd[:-1]]
 ds += [(hold,btn|(D[cmd[-2]] if len(cmd)>1 else 0)),(2,0)]
 return ds
out=[]
chosen=[(0,'236A','236A',4,4),(0,'236A','63214A',4,4),(0,'236A','63214A',12,4),(0,'236B','B',4,12),(2,'214A','623A',4,4),(4,'[4]6B','6B',12,24),(5,'41236A','236A',4,4),(6,'41236A','236B',4,4),(8,'463214A','214A',4,48),(10,'214A','214A',4,4),(13,'214A','214A',4,4)]
for cid,start,follow,strong,delay in chosen:
 for side in [0,1]:
  for phase in [0,1]:
   row=[cid,start,follow,strong,delay,side,phase]
   for f in ['',follow,'SP']:
    e.load(p/(f'kof_flip{cid}.st' if side else f'kof_id{cid}.st'));e.run(35,64 if side else 128);e.run(20+phase);left=bool(e.ram()[0xd4c]&128)
    for n,v in command(start,strong):e.run(n,rp(v))
    e.run(delay);act=e.ram()[0xd3c];acts=[]
    if f=='SP':
     mod=(128 if left else 64) if cid==0 and start=='236A' and follow=='63214A' else 0
     for _ in range(2):
      e.run(1,2048|mod);a=e.ram()[0xd3c]
      if not acts or acts[-1]!=a:acts.append(a)
    for n,v in ([] if f=='SP' else command(f))+[(180,0)]:
     for _ in range(n):
      e.run(1,rp(v));a=e.ram()[0xd3c]
      if not acts or acts[-1]!=a:acts.append(a)
    row.append([act,acts])
   out.append(row)
 print(cid,start,follow,flush=True)
(p/'kof_follow_final.json').write_text(json.dumps(out));e.close()
